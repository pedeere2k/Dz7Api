// modulos-api/normalizador.js
function normalizarPaciente(d) {
  return {
    cns: d.cns,
    nome: d.nome,
    nome_mae: d.nome_mae,
    sexo: d.sexo.startsWith("M") ? "M" : "F",
    nascimento: d.nascimento,
    raca: d.raca,
    municipio_nascimento: d.municipio_nascimento,
    endereco: {
      logradouro: d.logradouro_tipo,
      nome: d.logradouro_nome,
      numero: d.numero,
      bairro: d.bairro,
      cep: d.cep,
      municipio: d.municipio,
      uf: d.uf
    },
    contato: {
      tipo: d.telefone_tipo,
      ddd: d.ddd,
      numero: d.telefone
    },
    documentos: {
      cpf: d.cpf,
      rg: {
        numero: d.rg,
        orgao: d.rg_orgao,
        uf: d.rg_uf,
        emissao: d.rg_emissao
      }
    }
  }
}

module.exports = { normalizarPaciente }