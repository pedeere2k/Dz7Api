// modulos-api/consultaCpf.js
async function consultarCPF(cpf) {
  /**
   * Aqui você conecta a base autorizada ou serviço interno
   * Por enquanto podemos usar mock para teste
   */
  return {
    cns: "700000000000000",
    nome: "STRING",
    nome_mae: "STRING",
    sexo: "FEMININO",
    nascimento: "1988-06-12",
    raca: "BRANCA",
    municipio_nascimento: "CHAPECÓ-SC",
    logradouro_tipo: "RUA",
    logradouro_nome: "ISRAEL",
    numero: "1621",
    bairro: "PASSO DOS FORTES",
    cep: "89805-730",
    municipio: "CHAPECÓ-SC",
    uf: "SC",
    telefone_tipo: "CELULAR",
    ddd: "49",
    telefone: "999999999",
    cpf,
    rg: "0000000",
    rg_orgao: "SSP",
    rg_uf: "SC",
    rg_emissao: "2000-04-14"
  }
}

module.exports = { consultarCPF }